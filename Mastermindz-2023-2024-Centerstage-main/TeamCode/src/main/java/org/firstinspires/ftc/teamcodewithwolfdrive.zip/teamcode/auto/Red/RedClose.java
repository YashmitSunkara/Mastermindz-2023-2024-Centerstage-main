package org.firstinspires.ftc.teamcode.auto.Red;

public class RedClose {
}
